package com.tcs.first;

interface it2 {
	void add(int a, int b);

}

public class secondProg {

	public static void main(String[] args) {
		// application with anonymous
		it2 i = new it2() {

			@Override
			public void add(int a, int b) {
				System.out.println(a + b);

			}

		};
		i.add(3, 5);

		// application with Lambda
		it2 j = (a, b) -> System.out.println(a + b);
		j.add(10, 30);

	}

}
