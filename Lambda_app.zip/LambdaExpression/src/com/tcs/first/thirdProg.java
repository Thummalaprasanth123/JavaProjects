package com.tcs.first;
interface it3{
	String disp(int a);
}

public class thirdProg {

	public static void main(String[] args) {
		//application with anonymous
		
	it3 k=new it3() {
		public String disp(int a)
		{
		  System.out.println(a);
		  return "rrr";
		}
	    };
		String aa=k.disp(10);
		System.out.println(aa);
		
		//application with Lambda ex1
		
		it3 l=(b)->{System.out.println(b);
		    return "bb";    
		};  
		String bb =l.disp(20);
		System.out.println(bb);
		
		//application with Lambda ex2
		
		it3 m=(x)->"amirkhan";
		String cc =m.disp(444);
		System.out.println(cc);
		
	}

}
