package com.tcs.first;
interface it1 {
	void disp();
	void show();
//	default void show() {
//		System.out.println("default method inside interface");
//	}
//	static void display() {
//		System.out.println("static method inside interface");
//	}
//	
}
public class firstProg implements it1 {

	public static void main(String[] args) {
	
		it1 i=()->{System.out.println("111111111");
		System.out.println("22222222222222");};
		i.disp();
		i.show();
		
	}
	}

output:
	
	Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
		The target type of this expression must be a functional interface

		at com.tcs.first.firstProg.main(firstProg.java:17)



